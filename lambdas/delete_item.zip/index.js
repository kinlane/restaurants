// Added to handle injection
const vandium = require( 'vandium' );
var mysql      = require('mysql');

  var connection = mysql.createConnection({
    host     : process.env.host,
    user     : process.env.user,
    password : process.env.password,
    database : process.env.database
  });

exports.handler = vandium.generic()
    .handler( (event, context, callback) => {

  var sql = "DELETE FROM items WHERE item_ID = " + connection.escape(event.item_id);

  connection.query(sql, function (error, results, fields) {

  var response = {};
  response['deleted'] = event.item_id;

  callback( null, results );

  });
});
